package com.example.reza.currencyconverteroffline;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText editUSD = (EditText) findViewById(R.id.editText1);
        final EditText editBDT = (EditText) findViewById(R.id.editText2);
        final EditText editPKR = (EditText) findViewById(R.id.editText3);
        final EditText editCNY = (EditText) findViewById(R.id.editText4);
        final EditText editAUD = (EditText) findViewById(R.id.editText5);
        final EditText editGBP = (EditText) findViewById(R.id.editText6);
        final EditText editCAD = (EditText) findViewById(R.id.editText7);
        final EditText editEUR = (EditText) findViewById(R.id.editText8);
        ((Button) findViewById(R.id.button1)).setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                double USD = Double.valueOf(editUSD.getText().toString()).doubleValue();
                double PKR = USD *  129.000d;
                double CNY = USD *  6.812d;
                double AUD = USD *  1.352d;
                double GBP = USD *  0.763d;
                double CAD = USD*  1.307d;
                double EUR = USD *  0.856d;
                editBDT.setText(String.valueOf(USD * 84.505d));
                editPKR.setText(String.valueOf(PKR));
                editCNY.setText(String.valueOf(CNY));
                editAUD.setText(String.valueOf(AUD));
                editGBP.setText(String.valueOf(GBP));
                editCAD.setText(String.valueOf(CAD));
                editEUR.setText(String.valueOf(EUR));
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

}
