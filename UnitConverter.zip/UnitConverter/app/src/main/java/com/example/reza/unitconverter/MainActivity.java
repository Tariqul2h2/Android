package com.example.reza.unitconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText editCentimeters = (EditText) findViewById(R.id.editText1);
        final EditText editInches = (EditText) findViewById(R.id.editText2);
        final EditText editMeters = (EditText) findViewById(R.id.editText3);
        final EditText editKms = (EditText) findViewById(R.id.editText4);
        final EditText editMiles = (EditText) findViewById(R.id.editText5);
        final EditText editMm = (EditText) findViewById(R.id.editText6);
        final EditText editFeet = (EditText) findViewById(R.id.editText7);
        final EditText editYards = (EditText) findViewById(R.id.editText8);
        ((Button) findViewById(R.id.button1)).setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                double centimeters = Double.valueOf(editCentimeters.getText().toString()).doubleValue();
                double meters = centimeters * 0.01d;
                double kms = centimeters * 1.0E-5d;
                double miles = centimeters * 6.2E-6d;
                double mm = centimeters * 10.0d;
                double feet = centimeters * 0.032d;
                double yards = centimeters * 0.01094d;
                editInches.setText(String.valueOf(centimeters * 0.393707d));
                editMeters.setText(String.valueOf(meters));
                editKms.setText(String.valueOf(kms));
                editMiles.setText(String.valueOf(miles));
                editMm.setText(String.valueOf(mm));
                editFeet.setText(String.valueOf(feet));
                editYards.setText(String.valueOf(yards));
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

}
