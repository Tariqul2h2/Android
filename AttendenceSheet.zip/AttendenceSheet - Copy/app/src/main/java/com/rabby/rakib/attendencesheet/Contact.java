package com.rabby.rakib.attendencesheet;

/**
 * Created by RAKIB on 6/19/2016.
 */
public class Contact {
   // int id;
    String name,email,uname,upass;

   /* public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return this.id;
    }
*/
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return this.email;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getUname() {
        return this.uname;
    }

    public void setUpass(String upass) {
        this.upass = upass;
    }

    public String getUpass() {
        return this.upass;
    }
}
