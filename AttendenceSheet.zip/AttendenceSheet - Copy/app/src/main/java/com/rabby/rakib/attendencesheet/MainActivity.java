package com.rabby.rakib.attendencesheet;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper Mydb= new DatabaseHelper(this);
    Button buttonsign;
    Button b2;
    EditText euser;
    EditText epass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonsign=(Button)findViewById(R.id.signinbutton);
        b2=(Button)findViewById(R.id.signupB);
        euser=(EditText)findViewById(R.id.editUser);
        epass=(EditText)findViewById(R.id.editPass);
        SigninButtonActivity();
        SignupButtonActivity();
    }

    public void SigninButtonActivity() {
        buttonsign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String struser=euser.getText().toString();
                String strpass=epass.getText().toString();
               // String Lusername=myDB.searchPass(struser);
                String Lpassword=Mydb.searchPass(struser);
                if(strpass.equals(Lpassword))
                {
                    Intent inet=new Intent(MainActivity.this, Login.class);
                    inet.putExtra("Username",struser);
                    startActivity(inet);
                }
                /*if(struser.equals(Lusername) && strpass.equals(Lpassword))
                {
                    Intent inet=new Intent(MainActivity.this, Login.class);
                    inet.putExtra("Username",struser);
                    startActivity(inet);
                }*/
                else Toast.makeText(MainActivity.this, "Username and Password don't match \n", Toast.LENGTH_SHORT).show();
               // else if(!struser.equals(Lusername)) Toast.makeText(MainActivity.this, "Username don't match \n", Toast.LENGTH_SHORT).show();
               // else if(!strpass.equals(Lpassword)) Toast.makeText(MainActivity.this, "Password don't match\n", Toast.LENGTH_SHORT).show();




            }
        });
    }
    public void SignupButtonActivity() {
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str=euser.getText().toString();
                Intent inet=new Intent(MainActivity.this, Signup.class);
                startActivity(inet);
            }
        });
    }
}
