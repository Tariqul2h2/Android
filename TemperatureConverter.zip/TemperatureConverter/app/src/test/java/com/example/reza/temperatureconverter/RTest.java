package com.example.reza.temperatureconverter;

import static org.junit.Assert.*;

public class RTest {

}